## Java Goof

This is a collection of Java demo apps that are vulnerable in different ways.

It's divided into modules, each one having its own README:

* [Todolist Goof](todolist-goof/README.md)
* [Log4Shell Goof](log4shell-goof/README.md)
* [Quickstart for running both Todolist with Log4Shell in Kubernetes](README-K8S.md)